let boutton = document.getElementById('declic');


boutton.addEventListener('click',()=>{
    var nomEntre = document.getElementById('nom').value;
    var descriptionEntre = document.getElementById('description').value;
    var ageEntre = document.getElementById('age').value;
     var NakenameEntre = document.getElementById('Nakename').value;

 var employeeEntre = document.getElementById('employee').value;


    var table = document.getElementById('listeUtilisateur').getElementsByTagName('tbody')[0];

    var range = table.insertRow();

    var cellule1 = range.insertCell()
    var cellule2 = range.insertCell()
    var cellule3 = range.insertCell()
     var cellule4 = range.insertCell()
    var cellule5 = range.insertCell()



    cellule1.innerHTML = nomEntre;
    cellule2.innerHTML = descriptionEntre;
    cellule3.innerHTML = ageEntre;
     cellule4.innerHTML = NakenameEntre;
    cellule5.innerHTML = employeeEntre;
});
