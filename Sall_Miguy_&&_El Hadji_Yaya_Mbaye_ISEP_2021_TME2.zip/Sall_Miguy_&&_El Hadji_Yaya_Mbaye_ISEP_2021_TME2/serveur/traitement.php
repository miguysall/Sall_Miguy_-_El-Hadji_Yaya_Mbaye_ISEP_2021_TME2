<?php

// sauvegarde dans la base $_POST

header('Location: ../fordescription.html');
