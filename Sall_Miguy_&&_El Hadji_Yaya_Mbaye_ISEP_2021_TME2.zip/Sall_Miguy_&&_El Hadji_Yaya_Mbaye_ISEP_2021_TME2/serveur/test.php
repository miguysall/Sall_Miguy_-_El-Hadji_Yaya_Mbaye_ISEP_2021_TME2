<?php

$etudiant = [
	["N"=> 3, "nom"=> "diop", "prenom"=>"pathe", "email"=> "pathe.diop@isep.edu.sn"],
		["N"=> 4, "nom"=> "Diouf", "prenom"=>"ngor", "email"=> "ngor.Diouf@isep.edu.sn"],
			["N"=> 5, "nom"=> "diagne", "prenom"=>"anna", "email"=> "anna.diagne@isep.edu.sn"],
				["N"=> 6, "nom"=> "ndiaye", "prenom"=>"fatou", "email"=> "fatou.ndiaye@isep.edu.sn"],
];

echo json_encode($etudiant);